 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\EMA\ExportFolder\0\103135\Output\AltiumDesigner\AltiumDesigner\AltiumDesigner
 
 
To import your new library part into Altium follow these steps:

1. After running the Ultra Librarian export for the first time,
you will need to copy the following files into an area where
they can be accessed for all future translations.  They are script
files that Altium will need to be able to find.
	a. UL_Form.dfm
	b. UL_Form.pas
	c. UL_Import.pas
	d. UL_Import.prjScr
	
2. The above script file will need to be run from within Altium.
This can be done by going to File, Open and selecting the
UL_Import.PrjScr file stored above.

3. Select the UL_Form.pas file form the new project that has loaded,
and then select runfrom the drop down menu.  You will need to select
the form again. Run the form.

3. When the script is run, it will ask you for the file name of the
Ultra Librarian file to run.  You should select the latest file
produced with a date code (for instance 2010-02-17_23-12-34.txt).

4. The script will open a new Integraged Library project and import
the Ultra Librarian data into it.  When complete a message box
will pop up saying that import is done.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_import.html

For a video tutorial, please visit:
http://youtu.be/pih50yx9HYU
 
 
Component "TPS78230DDCR" renamed to "TPS78230DDCR"


Ultra Librarian Gold 8.2.80 Process Report



TextStyle count:  25
Padstack count:   3
Pattern count:    3
Symbol count:     1
Component count:  1

Export

